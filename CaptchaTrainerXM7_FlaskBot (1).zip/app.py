
from flask import Flask, render_template, request
import os, random, telebot
from config import BOT_TOKEN

app = Flask(__name__)
bot = telebot.TeleBot(BOT_TOKEN)

@app.route('/')
def index():
    images = os.listdir('static/captcha_images')
    image = random.choice(images)
    return render_template('index.html', image_file=image)

@app.route(f'/{BOT_TOKEN}', methods=['POST'])
def webhook():
    update = telebot.types.Update.de_json(request.stream.read().decode("utf-8"))
    bot.process_new_updates([update])
    return '', 200

@bot.message_handler(commands=['start'])
def start(message):
    markup = telebot.types.InlineKeyboardMarkup()
    btn = telebot.types.InlineKeyboardButton("Start Captcha Training", url="https://your-render-app.onrender.com/")
    markup.add(btn)
    bot.send_message(message.chat.id, "Welcome to CaptchaTrainerXM7!", reply_markup=markup)

if __name__ == "__main__":
    app.run()
